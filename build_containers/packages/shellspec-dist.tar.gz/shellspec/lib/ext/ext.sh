#shellcheck shell=bash

# This is place folder to the module use extended shell language.
#
# Currently not implemented.
