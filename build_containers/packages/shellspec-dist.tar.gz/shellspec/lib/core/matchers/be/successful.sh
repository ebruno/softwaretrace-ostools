#shellcheck shell=sh

shellspec_syntax_alias 'shellspec_matcher_be_successful' 'shellspec_matcher_be_defined'
