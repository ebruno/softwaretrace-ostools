#shellcheck shell=sh

shellspec_syntax_chain 'shellspec_matcher_has'

shellspec_import 'core/matchers/has/stat'
