#shellcheck shell=sh

shellspec_syntax_chain 'shellspec_matcher_be'

shellspec_import 'core/matchers/be/empty'
shellspec_import 'core/matchers/be/stat'
shellspec_import 'core/matchers/be/status'
shellspec_import 'core/matchers/be/valid'
shellspec_import 'core/matchers/be/variable'
shellspec_import 'core/matchers/be/successful'
