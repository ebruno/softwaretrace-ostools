#!/bin/sh

# shellcheck disable=SC2034
{ VAR=var; } 2>/dev/null
